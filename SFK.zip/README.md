# Skånska Fältrittklubben — website

Static HTML/CSS site. No build step.

## Deploy to Vercel

### Option A — drag & drop (fastest)
1. Go to [vercel.com/new](https://vercel.com/new) and sign in.
2. Drag this folder onto the upload area, **or** click **"Deploy"** → **"Upload"** and pick the unzipped folder.
3. Vercel detects it as a static site (no framework). Click **Deploy**.
4. You get a `*.vercel.app` URL in ~10 seconds.

### Option B — Vercel CLI
```bash
npm i -g vercel
cd path/to/this/folder
vercel              # first run — links the project
vercel --prod       # promote to production
```

### Option C — connect a Git repo
1. Push this folder to a new GitHub/GitLab/Bitbucket repo.
2. In Vercel, **New Project** → import the repo → **Deploy**.
3. Every push to `main` auto-deploys.

## Custom domain
In the Vercel dashboard: **Project → Settings → Domains → Add**. Point your DNS at Vercel (they show you the exact `A` / `CNAME` records). HTTPS is automatic.

## What's in here
| File | |
|---|---|
| `index.html` | Homepage |
| `tavlingar.html` | Tävlingar (races) |
| `klubben.html` | Om klubben |
| `medlemskap.html` | Medlemskap |
| `nyheter.html` | Aktuellt / news |
| `kontakt.html` | Kontakt |
| `styles.css` | Shared styles + design tokens |
| `assets/` | Logos, mark, silks chevron |
| `vercel.json` | Clean URLs config |

## Notes
- `vercel.json` enables clean URLs — `/klubben` serves `klubben.html`. Existing `.html` links still work (Vercel redirects them).
- Photos are pulled from Unsplash. Swap to real SFK photography before going to a real production domain.
- Logos in `assets/` are placeholders per the design-system brief — replace with the official marks when available.
